// EjemploHerencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "Paralelogramo.h"
#include "conio.h"

using namespace std;

int main(void) {
   Rectangulo Rect;
   Paralelogramo Par;
 
   Rect.setWidth(5);
   Rect.setHeight(7);
   Par.setWidth(3);
   Par.setHeight(8);

   // Muestra el �rea de un rectangulo
   cout << "Total area: " << Rect.getArea() << endl;
   cout << "Total Area del Paralelogramo: " << Par.getArea() << endl;
   getch();
   return 0;
}