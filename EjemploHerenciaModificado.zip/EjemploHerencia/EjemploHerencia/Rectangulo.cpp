#include "StdAfx.h"
#include "Rectangulo.h"


Rectangulo::Rectangulo(void)
{
}


Rectangulo::~Rectangulo(void)
{
}
