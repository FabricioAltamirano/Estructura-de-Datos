#pragma once

namespace Ejemplo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for prueba
	/// </summary>
	public ref class prueba : public System::Windows::Forms::Form
	{
	public:
		prueba(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~prueba()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  textBox3;
	private: System::Windows::Forms::Button^  buttonsuma;
	private: System::Windows::Forms::Button^  buttonresta;
	private: System::Windows::Forms::Button^  buttonmulti;
	private: System::Windows::Forms::Button^  buttondivi;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->buttonsuma = (gcnew System::Windows::Forms::Button());
			this->buttonresta = (gcnew System::Windows::Forms::Button());
			this->buttonmulti = (gcnew System::Windows::Forms::Button());
			this->buttondivi = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(66, 34);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(76, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Primer N�mero";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(325, 34);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(90, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Segundo N�mero";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(23, 59);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(165, 20);
			this->textBox1->TabIndex = 2;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &prueba::textBox1_TextChanged);
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(273, 59);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(192, 20);
			this->textBox2->TabIndex = 3;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(199, 122);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(55, 13);
			this->label3->TabIndex = 4;
			this->label3->Text = L"Resultado";
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(129, 150);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(199, 20);
			this->textBox3->TabIndex = 5;
			// 
			// buttonsuma
			// 
			this->buttonsuma->Location = System::Drawing::Point(151, 205);
			this->buttonsuma->Name = L"buttonsuma";
			this->buttonsuma->Size = System::Drawing::Size(147, 40);
			this->buttonsuma->TabIndex = 6;
			this->buttonsuma->Text = L"SUMA";
			this->buttonsuma->UseVisualStyleBackColor = true;
			this->buttonsuma->Click += gcnew System::EventHandler(this, &prueba::buttonsuma_Click);
			// 
			// buttonresta
			// 
			this->buttonresta->Location = System::Drawing::Point(152, 251);
			this->buttonresta->Name = L"buttonresta";
			this->buttonresta->Size = System::Drawing::Size(146, 47);
			this->buttonresta->TabIndex = 7;
			this->buttonresta->Text = L"RESTA";
			this->buttonresta->UseVisualStyleBackColor = true;
			// 
			// buttonmulti
			// 
			this->buttonmulti->Location = System::Drawing::Point(151, 304);
			this->buttonmulti->Name = L"buttonmulti";
			this->buttonmulti->Size = System::Drawing::Size(147, 38);
			this->buttonmulti->TabIndex = 8;
			this->buttonmulti->Text = L"MULTIPLICACION";
			this->buttonmulti->UseVisualStyleBackColor = true;
			// 
			// buttondivi
			// 
			this->buttondivi->Location = System::Drawing::Point(152, 348);
			this->buttondivi->Name = L"buttondivi";
			this->buttondivi->Size = System::Drawing::Size(146, 48);
			this->buttondivi->TabIndex = 9;
			this->buttondivi->Text = L"DIVISION";
			this->buttondivi->UseVisualStyleBackColor = true;
			// 
			// prueba
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(503, 431);
			this->Controls->Add(this->buttondivi);
			this->Controls->Add(this->buttonmulti);
			this->Controls->Add(this->buttonresta);
			this->Controls->Add(this->buttonsuma);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"prueba";
			this->Text = L"prueba";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void buttonsuma_Click(System::Object^  sender, System::EventArgs^  e) {
			 double num1, num2, res;
			 num1=System::Convert::ToInt32(PrimerNumero-> Text);
			 num2=System::Convert::ToInt32(SegundoNumero-> Text);
			 res=num1+num2;
			 Respusta->Text=System::Convert::Tostring(res);
		 }
};
}
