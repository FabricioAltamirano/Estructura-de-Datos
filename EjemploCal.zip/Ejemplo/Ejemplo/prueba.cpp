#include "prueba.h"
#include "stdafx.h"
using namespace prueba;
[STAThreadAttribute]

