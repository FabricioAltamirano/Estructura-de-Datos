#include "StdAfx.h"
#include "Dato.h"


Dato::Dato(void)
{
	Id=0;
	Numero=0;
	Nombre="Unknow";
}
