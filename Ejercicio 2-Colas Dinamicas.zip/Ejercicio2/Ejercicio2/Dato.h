
#pragma once 
#include <string>

using namespace std;

class Dato {
public: 
    int Id; 
    int Numero; 
    string Nombre; 
    Dato();
}; 
